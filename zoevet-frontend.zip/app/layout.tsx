import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Zoevet — Veterinary Products",
  description: "Zoevet veterinary e-commerce, doctor research portal and admin dashboard prototype."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
