import Link from "next/link";

export function Logo() {
  return <Link href="/store" className="logo"><span className="logo-mark">Z</span><span>Z O E V E T</span></Link>;
}

export function Icon({ children }: { children: React.ReactNode }) {
  return <span style={{fontSize:18,lineHeight:1}}>{children}</span>;
}

export function StoreHeader() {
  return <>
    <header className="topbar">
      <Logo />
      <div className="search"><Icon>⌕</Icon><input placeholder="Search for products, brands, or conditions..." /></div>
      <div className="top-actions">
        <Link href="/account" className="icon-btn">◉</Link>
        <Link href="/cart" className="icon-btn">🛒</Link>
      </div>
    </header>
    <nav className="nav">
      <Link href="/products">Products</Link>
      <Link href="/products?animal=dog">By Animal</Link>
      <Link href="/products">Brands</Link>
      <Link href="/products">Offers</Link>
      <Link href="/products">Pet Care</Link>
      <Link href="/doctor">Resources</Link>
    </nav>
  </>;
}

export function Footer(){ return <footer className="footer">© 2026 Zoevet · Veterinary Products for a Healthier World · A Product by CovianLab</footer> }

export const products = [
  {id:"petvit",name:"Petvit Multivitamin Tablets",price:450,old:600,rating:"4.6",reviews:120,img:"/images/petvit.jpg",badge:"Best Seller"},
  {id:"intas",name:"Intas Skin Care Shampoo",price:320,old:360,rating:"4.4",reviews:98,img:"/images/intas.jpg",badge:"10% OFF"},
  {id:"virbac",name:"Virbac NutriPlus Gel",price:650,old:720,rating:"4.8",reviews:76,img:"/images/virbac.jpg"},
  {id:"himalaya",name:"Himalaya Liv.52",price:350,old:399,rating:"4.5",reviews:84,img:"/images/himalaya.jpg"},
  {id:"bravecto",name:"Bravecto Chew",price:1250,old:1400,rating:"4.7",reviews:65,img:"/images/bravecto.jpg"},
  {id:"senry",name:"Senry Tick & Flea Collar",price:499,old:550,rating:"4.3",reviews:54,img:"/images/senry.jpg"}
];

export function ProductCard({p}:{p:typeof products[number]}) {
  return <div className="card product">
    {p.badge && <span className="badge">{p.badge}</span>}
    <div className="product-img"><img src={p.img} alt={p.name}/></div>
    <h3>{p.name}</h3>
    <div className="rating">★ {p.rating} ({p.reviews})</div>
    <div><span className="price">₹{p.price.toLocaleString("en-IN")}</span><span className="old">₹{p.old.toLocaleString("en-IN")}</span></div>
    <Link href="/cart"><button className="add">Add to Cart</button></Link>
  </div>
}
