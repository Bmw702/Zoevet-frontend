import Link from "next/link";
import {StoreHeader,Footer,products} from "../../ui";

export default async function ProductDetail({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const p=products.find(x=>x.id===id)||products[0];
 return <div className="shell"><StoreHeader/><main className="container"><div className="crumbs">Home / Dog / Supplements / {p.name}</div>
  <div className="detail">
   <div className="gallery"><div className="thumbs">{[1,2,3,4].map(i=><div className="thumb" key={i}><img src={p.img} alt=""/></div>)}</div><div className="main-product"><img src={p.img} alt={p.name}/></div></div>
   <div className="detail-copy"><span className="eyebrow">Vet approved</span><h1>{p.name}</h1><div className="rating-lg">★★★★★ {p.rating} ({p.reviews} reviews)</div><div><span className="price" style={{fontSize:26}}>₹{p.price}</span> <span className="old">₹{p.old}</span> <span className="status" style={{marginLeft:8}}>10% OFF</span></div><p className="desc">Complete nutritional support for active and healthy pets. Enriched with essential vitamins, minerals and antioxidants.</p><div className="filter-title">Size</div><div className="option"><button className="selected">60 Tablets</button><button>120 Tablets</button></div><div className="qty"><span className="filter-title" style={{margin:0}}>Quantity</span><button>−</button><b>1</b><button>+</button></div><div className="detail-buy"><Link href="/cart" className="btn primary" style={{textAlign:"center"}}>Add to Cart</Link><Link href="/checkout" className="btn secondary" style={{textAlign:"center"}}>Buy Now</Link></div><div className="feature-strip"><div className="feature">✓ Vet Approved</div><div className="feature">✓ Safe & Effective</div><div className="feature">✓ Trusted Brand</div></div></div>
  </div></main><Footer/></div>
}