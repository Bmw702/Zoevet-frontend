import Link from "next/link";
import {StoreHeader,Footer} from "../ui";

export default function Store(){
 return <div className="shell"><StoreHeader/><main className="container">
  <section className="hero">
   <div className="hero-copy">
    <span className="eyebrow">Trusted veterinary care</span>
    <h1>Better Care<br/>for Every Animal</h1>
    <p>Premium veterinary products, trusted by professionals, delivered to your doorstep.</p>
    <div className="hero-actions"><Link href="/products" className="btn primary">Shop Now</Link><Link href="/products" className="btn secondary">Explore by Animal</Link></div>
   </div>
   <div className="hero-image" />
  </section>
  <div className="trust-row">
   {["Trusted Products","Vet Approved","Fast Delivery","Better Animal Care"].map((x,i)=><div className="trust" key={x}><span className="trust-icon">{["✓","✚","↗","♥"][i]}</span><b>{x}</b></div>)}
  </div>
  <div className="section-head"><div><h2>Shop by Animal</h2><p>Find products made for their needs.</p></div><Link href="/products" className="muted">View all →</Link></div>
  <div className="category-grid">{[["🐶","Dogs"],["🐱","Cats"],["🐄","Cattle"],["🐔","Poultry"],["🐴","Equine"],["🐾","More Animals"]].map(([a,n])=><Link href="/products" className="category" key={n}><div className="animal">{a}</div><strong>{n}</strong></Link>)}</div>
  <div className="section-head"><div><h2>Popular Products</h2><p>Frequently selected by pet parents and veterinary professionals.</p></div><Link href="/products" className="muted">Browse products →</Link></div>
  <div className="grid">{[0,1,2].map(i=> <div className="card product" key={i}><div className="product-img"><img src={["/images/petvit.jpg","/images/intas.jpg","/images/virbac.jpg"][i]} alt="product"/></div><h3>{["Petvit Multivitamin Tablets","Intas Skin Care Shampoo","Virbac NutriPlus Gel"][i]}</h3><div className="rating">★ 4.7 · Vet approved</div><div className="price">₹{[450,320,650][i]}</div><Link href="/cart"><button className="add">Add to Cart</button></Link></div>)}</div>
 </main><Footer/></div>
}