import Link from "next/link";
import {StoreHeader,Footer,products,ProductCard} from "../ui";

export default function Products(){
 return <div className="shell"><StoreHeader/><main className="container">
  <div className="crumbs">Home / Products / Dogs</div>
  <div className="toolbar"><div><h1 style={{margin:"0 0 5px",fontSize:26}}>Dog Products <span className="muted">(124)</span></h1><span className="muted">Veterinary products for everyday animal care</span></div><select style={{padding:"10px 13px",border:"1px solid var(--line)",borderRadius:8,background:"#fff"}}><option>Sort by Relevance</option><option>Price: Low to High</option><option>Rating</option></select></div>
  <div className="layout">
   <aside className="card filters"><h3>Filters</h3><div className="filter-group"><div className="filter-title">Animal</div>{["Dog","Cat","Poultry","Equine","Others"].map(x=><label className="check" key={x}><input type="checkbox"/>{x}</label>)}</div><div className="filter-group"><div className="filter-title">Category</div>{["Nutrition","Medicine","Supplements","Vaccines","Grooming","Accessories"].map(x=><label className="check" key={x}><input type="checkbox"/>{x}</label>)}</div><div className="filter-group"><div className="filter-title">Price Range</div><div className="muted">₹0 — ₹5,000</div><input type="range" min="0" max="5000" defaultValue="3000" style={{width:"100%",marginTop:10}}/></div></aside>
   <section className="grid">{products.map(p=><ProductCard p={p} key={p.id}/>)}</section>
  </div>
 </main><Footer/></div>
}